package project1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Movie {
	//Data fields
	private String movieTitle;
	private Date releaseDate;
	private String dateRel;
	private String type;
	private String description;
	private Date receivedDate;
	private String recDate;
	private enum status{
		RECEIVED, RELEASED
	}
	
	//Arraylist and scanner
	ArrayList<String> Movie = new ArrayList<String>();
	Scanner scnr = new Scanner (System.in);
	
	//Constructors
	//Default constructor
	public Movie() {};
	
	//Methods
	public void addMovie() throws Exception {
		System.out.println("Enter movie title:");
		movieTitle = scnr.next();
		System.out.println("Enter release date:");
		releaseDate = new SimpleDateFormat("MM/dd/yyyy").parse(dateRel);
		System.out.println("Enter movie type:");
		type = scnr.next();
		System.out.println("Enter description:");
		description = scnr.next();
		Movie.add(description);
		System.out.println("Enter recieved date");
		recDate = scnr.next();
		receivedDate = new SimpleDateFormat("MM/dd/yyyy").parse(recDate);
		
		//Check if release date is before or equal to received date
		if (releaseDate.compareTo(receivedDate) == 0) {
			System.out.print("Invalid release date.");
		}
		else if (releaseDate.compareTo(receivedDate) < 0) {
			System.out.print("Invalid release date.");
		}
		else {
			Movie.add(movieTitle);
			Movie.add(dateRel);
			dateRel = scnr.next();
			Movie.add(type);
			Movie.add(recDate);
		}
		
		
	}
	
	
	public void showing() {
		
	}
	
	public void coming() {
		
	}
	
}
