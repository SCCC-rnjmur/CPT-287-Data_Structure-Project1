package project1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Movie {
	//Data fields
	private String movieTitle;
	private Date releaseDate;
	private String dateRel;
	private String type;
	private String description;
	private Date receivedDate;
	private String recDate;
	String[] Movie = new String[4];
	private enum status{
		RECEIVED, RELEASED
	}
	
	
	//Constructors
	//Default constructor
	public Movie() {};
	
	//Methods
	public void addMovie() throws Exception {
		Scanner scnr = new Scanner (System.in);
		System.out.println("Enter movie title:");
		movieTitle = scnr.next();
		Movie[0] = movieTitle;
		System.out.println("Enter release date:");
		dateRel = scnr.next();
		Movie[1] = dateRel;
		releaseDate = new SimpleDateFormat("MM/dd/yyyy").parse(dateRel);
		System.out.println("Enter movie type:");
		type = scnr.next();
		Movie[2] = type;
		System.out.println("Enter description:");
		description = scnr.next();
		Movie[3] = description;
		System.out.println("Enter recieved date");
		recDate = scnr.next();
		Movie[4] = recDate;
		receivedDate = new SimpleDateFormat("MM/dd/yyyy").parse(recDate);
		
		//Check if release date is before or equal to received date
		if (releaseDate.compareTo(receivedDate) == 0) {
			System.out.print("Invalid release date.");
		}
		else if (releaseDate.compareTo(receivedDate) < 0) {
			System.out.print("Invalid release date.");
		}
		
		
	}
	
	
	public void showing() {
		
	}
	
	public void coming() {
		
	}
	
}
